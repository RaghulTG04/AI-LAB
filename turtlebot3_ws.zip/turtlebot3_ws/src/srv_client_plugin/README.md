# srv_client_plugin Package

Author: Roberto Zegers R.  
Date: November 2020  
License: BSD-3-Clause  

## Decription

A global planner that creates service request to get a plan and forwards the response to the move_base global planner module.  



