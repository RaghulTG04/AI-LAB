# The pp_msgs Package

Author: Roberto Zegers R.  
Date: November 2020  
License: BSD-3-Clause  

## Description

Messages and services for the mapping and path planning course.  


